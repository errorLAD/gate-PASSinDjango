from django.db import models
from django.contrib.auth.models import User

#create the class

class Product(models.Model):
    name = models.CharField(max_length=255)
    pub_date = models.DateTimeField()
    email = models.EmailField(max_length=254)
    phone_number = models.IntegerField(default=1)
    gender = models.CharField(max_length=10)
    image = models.ImageField(upload_to='images/')
    icon = models.ImageField(upload_to='images/')
    location = models.CharField(max_length=200)
    body = models.TextField() 
  
    def pub_date_pretty(self):
        return self.pub_date.strftime('%b %e, %Y')

    def __str__(self):
            return self.name

