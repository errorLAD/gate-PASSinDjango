  
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Product
from django.utils import timezone
@login_required(login_url="/accounts/login")
def home(request):
    products = Product.objects
    return render(request, 'products/home.html', {'products': products})

@login_required(login_url="/accounts/login")
def create(request):
    if request.method == "POST":
        if request.POST['name'] and request.POST['email'] and request.POST['phone_number'] and request.POST['gender'] and request.FILES['image'] and request.FILES['icon'] and request.POST['location'] and request.POST['body']:
           product = Product()
           product.name  = request.POST['name']
           product.email = request.POST['email']
           product.phone_number = request.POST['phone_number'] 
           product.gender = request.POST['gender']  
           product.image  = request.FILES['image']
           product.icon = request.FILES['icon']
           product.location = request.POST['location']
           product.pub_date = timezone.datetime.now()
           product.body = request.POST['body']
           product.save()
           return redirect('/products/' + str(product.id))

        else:
            return render(request, 'products/create.html', {'error':'please fill all the fields'})
    else:
        return render(request, 'products/create.html')



def detail(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    return render(request, 'products/detail.html', {'product':product})
